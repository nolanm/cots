<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['name']        = esc_html__( 'Sermon', 'bridge' );
$manifest['description'] = esc_html__(
	'Sermon is a extension to manage your church’s sermons and sermon series! Fully compatible with the brand new WordPress.',
	'bridge'
);
$manifest['version'] = '1.0';

$manifest['display'] = true;
$manifest['standalone'] = true;
$manifest['thumbnail'] = 'fa fa-file-text-o';
