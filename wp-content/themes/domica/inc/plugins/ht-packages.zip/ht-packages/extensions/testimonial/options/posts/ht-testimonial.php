<?php
/**
 * Option metabox for Recipe post
 * @var array
 * @package bridge
 */

$options = array(
    'metabox' => array(
        'type'     => 'box',
        'title'    => esc_html__( 'Testimonial Settings', 'bridge' ),
        'priority' => 'high',
        'options'  => array(
            'name'  => array(
                'type'  => 'text',
                'label' => esc_attr__( 'Name / Company', 'bridge' ),
            ),
            'position'  => array(
                'type'  => 'text',
                'label' => esc_attr__( 'Position', 'bridge' ),
            )
        )

    )
);