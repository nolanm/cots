<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

/**
 * Replace the content of the current template with the content of event view
 *
 * @param string $the_content
 *
 * @return string
 */
function _filter_fw_ext_staff_the_content( $the_content ) {

	/**
	 * @var FW_Extension_Staff $staff
	 */
	$staff = fw()->extensions->get( 'ht-staff' );

	return fw_render_view( $staff->locate_view_path( 'single' ), array( 'the_content' => $the_content ) );
}

/**
 * Select custom page template on frontend
 *
 * @internal
 *
 * @param string $template
 *
 * @return string
 */
function _filter_fw_ext_staff_template_include( $template ) {

	/**
	 * @var FW_Extension_Staff $staff
	 */
	$staff = fw()->extensions->get( 'staff' );

	if ( is_singular( $staff->get_post_type_name() ) ) {
		if ( $staff->locate_view_path( 'single' ) ) {
			return $staff->locate_view_path( 'single' );
		}

		add_filter( 'the_content', '_filter_fw_ext_staff_the_content' );
	} else if ( is_tax( $staff->get_taxonomy_name() ) && $staff->locate_view_path( 'taxonomy' ) ) {
		return $staff->locate_view_path( 'taxonomy' );
	}

	return $template;
}

add_filter( 'template_include', '_filter_fw_ext_staff_template_include' );
