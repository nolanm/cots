<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

/**
 * Replace the content of the current template with the content of event view
 *
 * @param string $the_content
 *
 * @return string
 */
function _filter_fw_ext_sermon_the_content( $the_content ) {

	/**
	 * @var FW_Extension_Sermon $sermon
	 */
	$sermon = fw()->extensions->get( 'ht-sermon' );

	return fw_render_view( $sermon->locate_view_path( 'single' ), array( 'the_content' => $the_content ) );
}

/**
 * Select custom page template on frontend
 *
 * @internal
 *
 * @param string $template
 *
 * @return string
 */
function _filter_fw_ext_sermon_template_include( $template ) {

	/**
	 * @var FW_Extension_Sermon $sermon
	 */
	$sermon = fw()->extensions->get( 'sermon' );

	if ( is_singular( $sermon->get_post_type_name() ) ) {
		if ( $sermon->locate_view_path( 'single' ) ) {
			return $sermon->locate_view_path( 'single' );
		}

		add_filter( 'the_content', '_filter_fw_ext_sermon_the_content' );
	} else if ( is_tax( $sermon->get_taxonomy_name() ) && $sermon->locate_view_path( 'taxonomy' ) ) {
		return $sermon->locate_view_path( 'taxonomy' );
	}

	return $template;
}

add_filter( 'template_include', '_filter_fw_ext_sermon_template_include' );
