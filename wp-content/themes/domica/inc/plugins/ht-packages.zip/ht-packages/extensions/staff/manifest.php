<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['name']        = esc_html__( 'Staff', 'bridge' );
$manifest['description'] = esc_html__(
	'Staff is a extension to display staff members in our teams! Fully compatible with the brand new WordPress.',
	'bridge'
);
$manifest['version'] = '1.0';

$manifest['display'] = true;
$manifest['standalone'] = true;
$manifest['thumbnail'] = 'fa fa-users';
