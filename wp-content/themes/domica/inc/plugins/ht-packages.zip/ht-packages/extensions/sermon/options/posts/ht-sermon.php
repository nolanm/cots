<?php
/**
 * Option metabox for Recipe post
 * @var array
 * @package bridge
 */
$options = array(
    'metabox' => array(
        'type'     => 'tab',
        'title'    => esc_html__( 'Sermon Settings', 'bridge' ),
        'priority' => 'high',
        'options'  => array(
            // 'sermon_speaker'  => array(
            //     'type'  => 'text',
            //     'label' => esc_attr__( 'Speaker Name', 'bridge' ),
            //     'desc'=> wp_kses_post('Enter spearker name'),
            //     'value'=> 'Micheal Knoll'
            // ),
            'sermon_description'  => array(
                'type'  => 'textarea',
                'label' => esc_attr__( 'Sermon short description', 'bridge' ),
                'desc'=> wp_kses_post('Enter description for sermon'),
                'value'=> 'We are going out in the community and serving  love it if you could join us.'
            ),
            'sermon_video_link' => array(
                'label'   => esc_html__('Sermon Video/Vimeo Link', 'bridge'),
                'type'    => 'text',
                'desc'   => wp_kses_post('Enter video url here. This options support Vimeo and Youtube. Ex: https://vimeo.com/137213101', 'bridge'),
                'value' => 'https://www.youtube.com/watch?v=RH3OxVFvTeg'    
            ),
            // 'sermon_audio_link' => array(
            //     'label'   => esc_html__('Sermon Audio Link', 'bridge'),
            //     'desc'   => esc_html__('Enter audio url. This option support soundcloud. Ex: https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/243823577&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false', 'bridge'),
            //     'type'    => 'text',
               
            // ),
            'sermon_audio_link' => array(
                'label' => __('Sermon audio link', 'bridge'),
                'type'  => 'upload',
                'desc'  => __('Upload an audio file. This option support mp3/mp4 file.', 'bridge'),
                'value' => array(
                ),
                /**
                 * If set to `true`, the option will allow to upload only images, and display a thumb of the selected one.
                 * If set to `false`, the option will allow to upload any file from the media library.
                 */
                'images_only' => false,
                /**
                 * An array with allowed files extensions what will filter the media library and the upload files.
                 */
                'files_ext' => array( 'doc', 'pdf', 'zip', 'mp3', 'mp4'),
                /**
                 * An array with extra mime types that is not in the default array with mime types from the javascript Plupload library.
                 * The format is: array( '<mime-type>, <ext1> <ext2> <ext2>' ).
                 * For example: you set rar format to filter, but the filter ignore it , than you must set
                 * the array with the next structure array( '.rar, rar' ) and it will solve the problem.
                 */
                'extra_mime_types' => array( 'audio/x-aiff, aif aiff' )
            ),
            'sermon_pdf_link'=> array(
                'label' => esc_html__('Sermon PDF Link', 'bridge'),
                'desc'   => esc_html__('Enter audio url', 'bridge'),
                'type'    => 'text',
                'value'=> 'http://my-religion.cmsmasters.net/wp-content/uploads/2016/06/pdfchurch.pdf'
            ),
        )   
    ),
     /*header*/
    'page_header' => array(
        'title'   => esc_html__('Header', 'bridgez'),
        'type'    => 'tab',
        'options' => array(
            /*header layout*/
            'page_header_layout' => array(
                'label' => false,
                'desc' => false,
                'type' => 'multi-picker',
                'picker' => array(
                    'gadget' => array(
                        'label' => esc_html__('Layout', 'bridgez'),
                        'type' => 'short-select',
                        'choices' => array(
                            'default' => esc_html__('Default', 'bridgez'),
                            'layout-1' => esc_html__('Layout 1', 'bridgez'),
                            'layout-2' => esc_html__('Layout 2', 'bridgez'),
                            'layout-3' => esc_html__('Layout 3 - Transparent', 'bridgez'),
                        ),
                        'value' => 'default',
                    )
                ),
                'choices' => array(
                    'layout-2' => array(
                        'layout-2-bg-topbar' => array(
                            'type' => 'rgba-color-picker',
                            'label' => esc_html__('Topbar background', 'bridgez'),
                            'desc' => esc_html__('Choose color', 'bridgez'),
                            'value' => 'rgba(255,255,255,0)'
                        ),
                        'layout-2-topbar-txt-color' => array(
                            'type' => 'color-picker',
                            'label' => esc_html__('Topbar text color', 'bridgez'),
                            'desc' => esc_html__('Choose color', 'bridgez'),
                            'value' => ''
                        ),
                        'layout-2-line-topbar' => array(
                            'type' => 'color-picker',
                            'label' => esc_html__('Topbar border color', 'bridgez'),
                            'desc' => esc_html__('Choose color', 'bridgez'),
                            'value' => ''
                        ),
                        'layout-2-bg-menu' => array(
                            'type' => 'rgba-color-picker',
                            'label' => esc_html__('Menu background', 'bridgez'),
                            'desc' => esc_html__('Choose color', 'bridgez'),
                            'value' => 'rgba(255,255,255,0)'
                        ),
                        'layout-2-menu-txt-color' => array(
                            'type' => 'color-picker',
                            'label' => esc_html__('Heading menu text color', 'bridgez'),
                            'desc' => esc_html__('Choose color', 'bridgez'),
                            'value' => ''
                        ),
                        'layout-2-btn-bg' => array(
                            'type' => 'color-picker',
                            'label' => esc_html__('Button background', 'bridgez'),
                            'desc' => esc_html__('Choose color', 'bridgez'),
                            'value' => ''
                        ),
                        'layout-2-btn-color' => array(
                            'type' => 'color-picker',
                            'label' => esc_html__('Button text color', 'bridgez'),
                            'desc' => esc_html__('Choose color', 'bridgez'),
                            'value' => ''
                        ),
                    ),
                ),
            ),
            /*logo*/
            'p_lg' => array(
                'label' => false,
                'desc' => false,
                'type' => 'multi-picker',
                'picker' => array(
                    'gadget' => array(
                        'type' => 'short-select',
                        'label' => esc_html__('Logo', 'bridgez'),
                        'desc' => false,
                        'choices' => array(
                            'default' => esc_html__('Default', 'bridgez'),
                            'custom' => esc_html__('Custom', 'bridgez'),
                        ),
                        'value' => 'default'
                    )
                ),
                'choices' => array(
                    'custom' => array(
                        'lg_data' => array(
                            'label' => esc_html__('Choose image', 'bridgez'),
                            'type' => 'upload',
                            'images_only' => true
                        )
                    )
                ),
            ),
            /*crumbs header*/
            'p_page_header' => array(
                'label'   => false,
                'desc'   => false,
                'type'    => 'multi-picker',
                'picker' => array(
                    'gadget' => array(
                        'label' => esc_html__('Page Header Options', 'bridgez'),
                        'type' => 'short-select',
                        'choices' => array(
                            'default' => esc_html__('Default', 'bridgez'),
                            '1' => esc_html__('Custom', 'bridgez'),
                            'no' => esc_html__('Disable', 'bridgez'),
                        ),
                        'value' => 'default',
                    ),
                ),
                'choices' => array(
                    '1' => array(
                        'page_header_text_color' => array(
                            'label' => esc_html__('Text color', 'bridgez'),
                            'desc' => esc_html__('Display text color of page breadcumbs', 'bridgez'),
                            'type' => 'color-picker',
                            'value' => '#ffffff'
                        ),
                        'page_header_title' => array(
                            'label' => esc_html__('Alternative Title', 'bridgez'),
                            'desc' => esc_html__('This will replace heading page title', 'bridgez'),
                            'type' => 'text',
                            'value' => ''
                        ),
                        'page_header_text' => array(
                            'label' => esc_html__('Text Breadcrumb Align', 'bridgez'),
                            'desc' => esc_html__('This will align text breadcrumb left or center', 'bridgez'),
                            'type' => 'select',
                            'choices' => array(
                                'center' => esc_html__('Text Align Center', 'bridgez'),
                                'left' => esc_html__('Text Align Left', 'bridgez'),
                            ),

                            'value' => 'center'
                        ),
                        'page_header_bg' => array(
                            'label' => false,
                            'desc' => false,
                            'type' => 'multi-picker',
                            'picker' => array(
                                'gadget' => array(
                                    'label' => esc_html__('Background Style', 'bridgez'),
                                    'desc' => esc_html__('If select background image option, the theme recommends a header size of at least 1170 width pixels', 'bridgez'),
                                    'type' => 'select',
                                    'choices' => array(
                                        'img_bg' => esc_html__('Use Image', 'bridgez'),
                                        'color_bg' => esc_html__('Use Solid Color', 'bridgez'),
                                    ),
                                    'value' => 'color_bg'
                                )
                            ),
                            'choices' => array(
                                'img_bg' => array(
                                    'img_bg_data' => array(
                                        'label' => esc_html__('Single Upload (Images Only)', 'bridgez'),
                                        'type' => 'upload'
                                    )
                                ),
                                'color_bg' => array(
                                    'color_bg_data' => array(
                                        'label' => esc_html__('Background Color', 'bridgez'),
                                        'type' => 'color-picker',
                                        'value' => '#e9eceb'
                                    )
                                )
                            ),
                        ),
                    ),
                ),
            ),
        ),
    ),
);