<?php
/**
 * Option metabox for Recipe post
 * @var array
 * @package ht
 */

$page_options = array(
    /*header*/
    'page_header' => array(
        'title'   => esc_html__('Header', 'bridge'),
        'type'    => 'tab',
        'options' => array(
            /*header layout*/
            'page_header_layout' => array(
                'label' => false,
                'desc' => false,
                'type' => 'multi-picker',
                'picker' => array(
                    'gadget' => array(
                        'label' => esc_html__('Layout', 'bridge'),
                        'type' => 'short-select',
                        'choices' => array(
                            'default' => esc_html__('Default', 'bridge'),
                            'layout-1' => esc_html__('Layout 1', 'bridge'),
                            'layout-2' => esc_html__('Layout 2', 'bridge'),
                            'layout-3' => esc_html__('Layout 3', 'bridge'),
                            'layout-4' => esc_html__('Layout 4', 'bridge'),
                        ),
                        'value' => 'default',
                    )
                ),
                'choices' => array(
                    'layout-2' => array(
                        'layout-2-bg-topbar' => array(
                            'type' => 'rgba-color-picker',
                            'label' => esc_html__('Topbar background', 'bridge'),
                            'desc' => esc_html__('Choose color', 'bridge'),
                            'value' => 'rgba(255,255,255,0)'
                        ),
                        'layout-2-topbar-txt-color' => array(
                            'type' => 'color-picker',
                            'label' => esc_html__('Topbar text color', 'bridge'),
                            'desc' => esc_html__('Choose color', 'bridge'),
                            'value' => ''
                        ),
                        'layout-2-line-topbar' => array(
                            'type' => 'color-picker',
                            'label' => esc_html__('Topbar border color', 'bridge'),
                            'desc' => esc_html__('Choose color', 'bridge'),
                            'value' => ''
                        ),
                        'layout-2-bg-menu' => array(
                            'type' => 'rgba-color-picker',
                            'label' => esc_html__('Menu background', 'bridge'),
                            'desc' => esc_html__('Choose color', 'bridge'),
                            'value' => 'rgba(255,255,255,0)'
                        ),
                        'layout-2-menu-txt-color' => array(
                            'type' => 'color-picker',
                            'label' => esc_html__('Heading menu text color', 'bridge'),
                            'desc' => esc_html__('Choose color', 'bridge'),
                            'value' => ''
                        ),
                    ),
                ),
            ),
            /*logo*/
            'p_lg' => array(
                'label' => false,
                'desc' => false,
                'type' => 'multi-picker',
                'picker' => array(
                    'gadget' => array(
                        'type' => 'short-select',
                        'label' => esc_html__('Logo', 'bridge'),
                        'desc' => false,
                        'choices' => array(
                            'default' => esc_html__('Default', 'bridge'),
                            'custom' => esc_html__('Custom', 'bridge'),
                        ),
                        'value' => 'default'
                    )
                ),
                'choices' => array(
                    'custom' => array(
                        'lg_data' => array(
                            'label' => esc_html__('Choose image', 'bridge'),
                            'type' => 'upload',
                            'images_only' => true
                        )
                    )
                ),
            ),
            /*crumbs header*/
            'p_page_header' => array(
                'label'   => false,
                'desc'   => false,
                'type'    => 'multi-picker',
                'picker' => array(
                    'gadget' => array(
                        'label' => esc_html__('Breadcrumbs', 'bridge'),
                        'type' => 'short-select',
                        'choices' => array(
                            'default' => esc_html__('Default', 'bridge'),
                            '1' => esc_html__('Custom', 'bridge'),
                            'no' => esc_html__('Disable', 'bridge'),
                        ),
                        'value' => 'default',
                    ),
                ),
                'choices' => array(
                    '1' => array(
                        'page_header_text_color' => array(
                            'label' => esc_html__('Text color', 'bridge'),
                            'desc' => esc_html__('Display text color of page breadcumbs', 'bridge'),
                            'type' => 'color-picker',
                            'value' => '#ffffff'
                        ),
                        'page_header_title' => array(
                            'label' => esc_html__('Alternative Title', 'bridge'),
                            'desc' => esc_html__('This will replace heading page title', 'bridge'),
                            'type' => 'text',
                            'value' => 'This is my title!'
                        ),
                        'page_header_text' => array(
                            'label' => esc_html__('Text Header', 'bridge'),
                            'desc' => esc_html__('This will display under breadcrumbs (optional)', 'bridge'),
                            'type' => 'textarea',
                        ),
                        'page_header_bg' => array(
                            'label' => false,
                            'desc' => false,
                            'type' => 'multi-picker',
                            'picker' => array(
                                'gadget' => array(
                                    'label' => esc_html__('Background Style', 'bridge'),
                                    'desc' => esc_html__('If select background image option, the theme recommends a header size of at least 1170 width pixels', 'bridge'),
                                    'type' => 'select',
                                    'choices' => array(
                                        'img_bg' => esc_html__('Use Image', 'bridge'),
                                        'color_bg' => esc_html__('Use Solid Color', 'bridge'),
                                    ),
                                    'value' => 'color_bg'
                                )
                            ),
                            'choices' => array(
                                'img_bg' => array(
                                    'img_bg_data' => array(
                                        'label' => esc_html__('Single Upload (Images Only)', 'bridge'),
                                        'type' => 'upload'
                                    )
                                ),
                                'color_bg' => array(
                                    'color_bg_data' => array(
                                        'label' => esc_html__('Background Color', 'bridge'),
                                        'type' => 'color-picker',
                                        'value' => '#e9eceb'
                                    )
                                )
                            ),
                        ),
                    ),
                ),
            ),
        ),
    ),
    /*footer*/
    'page_footer' => array(
        'title'   => esc_html__('Footer', 'bridge'),
        'type'    => 'tab',
        'options' => array(
            'footer_data' => array(
                'label' => esc_html__('Layout', 'bridge'),
                'type' => 'short-select',
                'choices' => array(
                    'default' => esc_html__('Default', 'bridge'),
                    'enable' => esc_html__('Enable', 'bridge'),
                    'disable' => esc_html__('Disable', 'bridge'),
                ),
                'value' => 'default',
            ),
            'p_copyright' => array(
                'label' => esc_html__('Copyright', 'bridge'),
                'type' => 'short-select',
                'choices' => array(
                    'default' => esc_html__('Default', 'bridge'),
                    'disable' => esc_html__('Disable', 'bridge'),
                ),
                'value' => 'default',
            )
        ),
    ),
);
$options = array(
    'metabox' => array(
        'type'     => 'box',
        'title'    => esc_html__( 'Service Settings', 'health-guide' ),
        'options'  => array(
            'consult_icon'  => array(
                'type'  => 'icon-v2',
                'label'   => esc_html__( 'Icon', 'health-guide' ),
                'desc'    => esc_html__( 'Choose an Icon', 'health-guide' ),
                'modal_size' => 'large',
                'preview_size' => 'sauron',
            ),
            'consult_subtitle' => array(
                'label'   => esc_html__('Sub Title', 'health-guide'),
                'desc'   => esc_html__('Enter sub title title', 'health-guide'),
                'type'    => 'text',
            ),
            'consult_price' => array(
                'label'   => esc_html__('Price', 'health-guide'),
                'desc'   => esc_html__('Enter price', 'health-guide'),
                'type'    => 'text',
            ),
            'consult_schedule' => array(
                'label'   => esc_html__('Schedule (Month)', 'health-guide'),
                'desc'   => esc_html__('Enter schedule such as: /mo', 'health-guide'),
                'type'    => 'text',
            ),
            'consult_dayNumber' => array(
                'label'   => esc_html__('Day Number', 'health-guide'),
                'desc'   => esc_html__('Enter schedule such as: 30', 'health-guide'),
                'type'    => 'text',
            ),
            'consult_schedule2' => array(
                'label'   => esc_html__('Schedule (Day)', 'health-guide'),
                'desc'   => esc_html__('Enter schedule such as: days', 'health-guide'),
                'type'    => 'text',
            ),
        )
    )
);
